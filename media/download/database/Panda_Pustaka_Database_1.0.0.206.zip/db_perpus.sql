-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 24, 2014 at 07:44 PM
-- Server version: 5.5.32
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_perpus`
--
CREATE DATABASE IF NOT EXISTS `db_perpus` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `db_perpus`;

-- --------------------------------------------------------

--
-- Table structure for table `tb_anggota`
--

CREATE TABLE IF NOT EXISTS `tb_anggota` (
  `id_anggota` int(5) NOT NULL AUTO_INCREMENT,
  `nis_anggota` varchar(250) NOT NULL,
  `nama_anggota` varchar(250) NOT NULL,
  `jenis_kelamin` enum('Pria','Wanita') NOT NULL,
  `kelas_anggota` enum('10','11','12') NOT NULL,
  `jurusan_anggota` enum('TKJ','Otomotif','Mesin','Listrik','Administrasi Perkantoran','Niaga','Jasa Boga','Farmasi') NOT NULL,
  `status_anggota` enum('Aktif','Tidak Aktif') NOT NULL,
  `sekolah_anggota` enum('SMK WIRAKARYA 1 CIPARAY','SMK WIRAKARYA 2 CIPARAY','SMK AS-SHIFA CIPARAY') NOT NULL,
  `tanggal_daftar` date NOT NULL,
  `petugas_daftar` varchar(250) NOT NULL,
  `total_denda` int(250) NOT NULL,
  `password_anggota` varchar(250) NOT NULL,
  PRIMARY KEY (`id_anggota`),
  KEY `nama_anggota` (`nama_anggota`),
  KEY `nama_anggota_2` (`nama_anggota`),
  KEY `nama_anggota_3` (`nama_anggota`),
  KEY `nama_anggota_4` (`nama_anggota`),
  KEY `nama_anggota_5` (`nama_anggota`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tb_anggota`
--

INSERT INTO `tb_anggota` (`id_anggota`, `nis_anggota`, `nama_anggota`, `jenis_kelamin`, `kelas_anggota`, `jurusan_anggota`, `status_anggota`, `sekolah_anggota`, `tanggal_daftar`, `petugas_daftar`, `total_denda`, `password_anggota`) VALUES
(7, '0710.2011', 'JR', 'Pria', '12', 'TKJ', 'Aktif', 'SMK WIRAKARYA 1 CIPARAY', '2014-10-09', 'admin', 0, 'JR'),
(12, '1210.276', 'Raka Suryaardi Widjaja', 'Pria', '12', 'TKJ', 'Aktif', 'SMK WIRAKARYA 1 CIPARAY', '2014-10-09', 'admin', 1500, '12111997');

-- --------------------------------------------------------

--
-- Table structure for table `tb_buku`
--

CREATE TABLE IF NOT EXISTS `tb_buku` (
  `id_buku` int(10) NOT NULL AUTO_INCREMENT,
  `nama_buku` varchar(250) NOT NULL,
  `jumlah_buku` int(250) NOT NULL,
  `nama_pengarang` varchar(250) NOT NULL,
  `nama_penerbit` varchar(250) NOT NULL,
  `tahun_terbit` year(4) NOT NULL,
  `tanggal_daftar` date NOT NULL,
  `petugas_daftar` varchar(250) NOT NULL,
  `kategori_buku` enum('Sekolah','BSE','Novel','Anak - Anak','Remaja','Umum') NOT NULL,
  PRIMARY KEY (`id_buku`),
  KEY `nama_buku` (`nama_buku`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tb_buku`
--

INSERT INTO `tb_buku` (`id_buku`, `nama_buku`, `jumlah_buku`, `nama_pengarang`, `nama_penerbit`, `tahun_terbit`, `tanggal_daftar`, `petugas_daftar`, `kategori_buku`) VALUES
(1, 'Membuat Aplikasi Perpustakaan Dengan Visual Basic 6 Dan MySQL', 100, 'Raka Suryaardi Widjaja', 'Informatika', 2014, '2014-10-09', 'admin', 'Umum');

-- --------------------------------------------------------

--
-- Table structure for table `tb_denda`
--

CREATE TABLE IF NOT EXISTS `tb_denda` (
  `id_denda` int(250) NOT NULL AUTO_INCREMENT,
  `id_anggota` int(250) NOT NULL,
  `id_pinjam_detail` int(250) NOT NULL,
  `banyak_denda` int(250) NOT NULL,
  `tanggal_denda` date NOT NULL,
  `petugas_denda` varchar(250) NOT NULL,
  PRIMARY KEY (`id_denda`),
  KEY `id_pinjam_detail` (`id_pinjam_detail`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tb_kembali`
--

CREATE TABLE IF NOT EXISTS `tb_kembali` (
  `id_kembali` int(250) NOT NULL AUTO_INCREMENT,
  `id_pinjam_detail` int(250) NOT NULL,
  `id_anggota` int(250) NOT NULL,
  `nama_petugas` varchar(250) NOT NULL,
  `nama_anggota` varchar(250) NOT NULL,
  `nama_buku` varchar(250) NOT NULL,
  `jumlah_buku` int(250) NOT NULL,
  `tanggal_pinjam` date NOT NULL,
  `tanggal_kembali` date NOT NULL,
  `denda_kembali` int(250) NOT NULL,
  PRIMARY KEY (`id_kembali`),
  KEY `id_pinjam_detail` (`id_pinjam_detail`),
  KEY `id_anggota` (`id_anggota`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tb_petugas`
--

CREATE TABLE IF NOT EXISTS `tb_petugas` (
  `id_petugas` int(3) NOT NULL AUTO_INCREMENT,
  `nama_petugas` varchar(5) NOT NULL,
  `alamat_petugas` text NOT NULL,
  `password_petugas` varchar(250) NOT NULL,
  PRIMARY KEY (`id_petugas`),
  KEY `nama_petugas` (`nama_petugas`),
  KEY `nama_petugas_2` (`nama_petugas`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tb_petugas`
--

INSERT INTO `tb_petugas` (`id_petugas`, `nama_petugas`, `alamat_petugas`, `password_petugas`) VALUES
(1, 'root', 'Global Protective', 'toor'),
(7, 'admin', 'Internet', 'admin'),
(12, 'raka', 'Jln. Solokan Jeruk No.289', 'raka');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pinjam`
--

CREATE TABLE IF NOT EXISTS `tb_pinjam` (
  `id_pinjam` int(250) NOT NULL AUTO_INCREMENT,
  `id_anggota` int(250) NOT NULL,
  `nama_anggota` varchar(250) NOT NULL,
  `nama_petugas` varchar(250) NOT NULL,
  `tanggal_pinjam` date NOT NULL,
  `status_pinjam` enum('Pinjam','Kembali') NOT NULL,
  PRIMARY KEY (`id_pinjam`),
  UNIQUE KEY `id_pinjam_3` (`id_pinjam`),
  KEY `id_pinjam` (`id_pinjam`),
  KEY `id_pinjam_2` (`id_pinjam`),
  KEY `id_anggota` (`id_anggota`),
  KEY `nama_anggota` (`nama_anggota`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tb_pinjam_detail`
--

CREATE TABLE IF NOT EXISTS `tb_pinjam_detail` (
  `id_pinjam_detail` int(250) NOT NULL AUTO_INCREMENT,
  `id_pinjam` int(250) NOT NULL,
  `id_buku` int(250) NOT NULL,
  `nama_buku` varchar(250) NOT NULL,
  `jumlah_buku` int(250) NOT NULL,
  `tanggal_pinjam` date NOT NULL,
  `status_pinjam_detail` enum('Pinjam','Kembali') NOT NULL,
  PRIMARY KEY (`id_pinjam_detail`),
  KEY `id_pinjam` (`id_pinjam`),
  KEY `id_pinjam_2` (`id_pinjam`),
  KEY `id_pinjam_3` (`id_pinjam`),
  KEY `id_pinjam_4` (`id_pinjam`),
  KEY `id_pinjam_5` (`id_pinjam`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tb_request`
--

CREATE TABLE IF NOT EXISTS `tb_request` (
  `id_request` int(250) NOT NULL AUTO_INCREMENT,
  `id_pengirim` int(250) NOT NULL,
  `nama_pengirim` varchar(250) NOT NULL,
  `nama_penerima` varchar(250) NOT NULL,
  `id_petugas_tujuan` int(250) NOT NULL,
  `id_anggota_tujuan` int(250) NOT NULL,
  `perihal_request` varchar(250) NOT NULL,
  `konten_request` text NOT NULL,
  `tanggal_request` date NOT NULL,
  `waktu_request` time NOT NULL,
  `status_request` enum('Di Baca','Belum Di Baca') NOT NULL,
  PRIMARY KEY (`id_request`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tb_setting`
--

CREATE TABLE IF NOT EXISTS `tb_setting` (
  `id_setting` int(250) NOT NULL,
  `nama_setting` varchar(250) NOT NULL,
  `status_setting_enum` enum('Ya','Tidak') NOT NULL,
  `status_setting_text` varchar(250) NOT NULL,
  `code_get` varchar(250) NOT NULL,
  `code_send` varchar(250) NOT NULL,
  PRIMARY KEY (`id_setting`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_setting`
--

INSERT INTO `tb_setting` (`id_setting`, `nama_setting`, `status_setting_enum`, `status_setting_text`, `code_get`, `code_send`) VALUES
(1, 'Pop Up About', 'Ya', 'Ya', '', ''),
(2, 'Pop Up Message', 'Ya', 'Ya', '', ''),
(3, 'Aktivasi', 'Tidak', 'Tidak', '', ''),
(4, 'Kelas Anggota', 'Ya', '10', '', ''),
(5, 'Kelas Anggota', 'Ya', '11', '', ''),
(6, 'Kelas Anggota', 'Ya', '12', '', ''),
(7, 'Jurusan Anggota', 'Ya', 'TKJ', '', ''),
(8, 'Jurusan Anggota', 'Ya', 'Otomotif', '', ''),
(9, 'Jurusan Anggota', 'Ya', 'Mesin', '', ''),
(10, 'Jurusan Anggota', 'Ya', 'Listrik', '', ''),
(11, 'Jurusan Anggota', 'Ya', 'Administrasi Perkantoran', '', ''),
(12, 'Jurusan Anggota', 'Ya', 'Niaga', '', ''),
(13, 'Jurusan Anggota', 'Ya', 'Jasa Boga', '', ''),
(14, 'Jurusan Anggota', 'Ya', 'Farmasi', '', ''),
(15, 'Sekolah Anggota', 'Ya', 'SMK WIRAKARYA 1 CIPARAY', '', ''),
(16, 'Sekolah Anggota', 'Ya', 'SMK WIRAKARYA 2 CIPARAY', '', ''),
(17, 'Sekolah Anggota', 'Ya', 'SMK AS-SHIFA CIPARAY', '', ''),
(18, 'Kategori Buku', 'Ya', 'Sekolah', '', ''),
(19, 'Kategori Buku', 'Ya', 'BSE', '', ''),
(20, 'Kategori Buku', 'Ya', 'Novel', '', ''),
(21, 'Kategori Buku', 'Ya', 'Anak - Anak', '', ''),
(22, 'Kategori Buku', 'Ya', 'Remaja', '', ''),
(23, 'Kategori Buku', 'Ya', 'Umum', '', '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_denda`
--
ALTER TABLE `tb_denda`
  ADD CONSTRAINT `tb_denda_ibfk_1` FOREIGN KEY (`id_pinjam_detail`) REFERENCES `tb_kembali` (`id_pinjam_detail`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_kembali`
--
ALTER TABLE `tb_kembali`
  ADD CONSTRAINT `tb_kembali_ibfk_1` FOREIGN KEY (`id_pinjam_detail`) REFERENCES `tb_pinjam_detail` (`id_pinjam_detail`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tb_kembali_ibfk_2` FOREIGN KEY (`id_anggota`) REFERENCES `tb_pinjam` (`id_anggota`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_pinjam`
--
ALTER TABLE `tb_pinjam`
  ADD CONSTRAINT `tb_pinjam_ibfk_1` FOREIGN KEY (`id_anggota`) REFERENCES `tb_anggota` (`id_anggota`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_pinjam_detail`
--
ALTER TABLE `tb_pinjam_detail`
  ADD CONSTRAINT `tb_pinjam_detail_ibfk_1` FOREIGN KEY (`id_pinjam`) REFERENCES `tb_pinjam` (`id_pinjam`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
